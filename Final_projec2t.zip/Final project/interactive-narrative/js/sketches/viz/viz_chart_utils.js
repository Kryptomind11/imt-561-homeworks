// viz_chart_utils.js — small shared helpers for the data charts.
(function () {
    window.ChartUtils = {
        PALETTE: {
            blue:   [74, 144, 184],
            green:  [76, 167, 110],
            red:    [201, 79, 74],
            amber:  [224, 168, 78],
            slate:  [120, 134, 150],
            ink:    [45, 55, 65],
            grid:   [225, 228, 232]
        },
        // standard plot frame: returns inner rect {x,y,w,h}
        frame: function (manager) {
            var pad = { l: 56, r: 24, t: 54, b: 48 };
            var x = (manager.offsetX || 0);
            var y = (manager.offsetY || 0);
            var W = (manager.width || 600);
            var H = (manager.height || 520);
            return {
                x: x + pad.l, y: y + pad.t,
                w: W - pad.l - pad.r, h: H - pad.t - pad.b,
                ox: x, oy: y, W: W, H: H
            };
        },
        title: function (p, f, text, sub) {
            p.noStroke();
            p.fill(window.ChartUtils.PALETTE.ink);
            p.textAlign(p.LEFT, p.TOP);
            p.textSize(17);
            p.text(text, f.ox + 8, f.oy + 8);
            if (sub) {
                p.fill(120);
                p.textSize(12);
                p.text(sub, f.ox + 8, f.oy + 30);
            }
        },
        // animation eased factor based on scroll progress (0..1 inside section)
        reveal: function (progress) {
            var t = Math.max(0, Math.min(1, (progress - 0.05) / 0.45));
            return t * t * (3 - 2 * t);
        }
    };
})();
