// viz_title.js
// Section 0 — title screen with a slow "breathing" circle.
(function () {
    window.VizTitle = {
        draw: function (p, manager, ai, progress) {
            var cx = (manager.offsetX || 0) + (manager.width || 600) / 2;
            var cy = (manager.offsetY || 0) + (manager.height || 520) / 2;
            var base = Math.min(manager.width || 600, manager.height || 520);
            var t = (p.frameCount % 240) / 240;
            var phase = (1 - Math.cos(t * Math.PI * 2)) / 2;
            var rOuter = base * (0.20 + 0.10 * phase);
            var label = phase > 0.5 ? 'breathe in' : 'breathe out';

            p.push();
            p.noStroke();
            for (var i = 4; i >= 1; i--) {
                p.fill(90, 150, 190, 12);
                p.ellipse(cx, cy, rOuter * (1 + i * 0.18) * 2, rOuter * (1 + i * 0.18) * 2);
            }
            p.fill(74, 144, 184, 230);
            p.ellipse(cx, cy, rOuter * 2, rOuter * 2);
            p.fill(255, 255, 255, 60 + 120 * phase);
            p.ellipse(cx, cy, rOuter * 0.9, rOuter * 0.9);
            p.fill(255);
            p.textAlign(p.CENTER, p.CENTER);
            p.textSize(Math.max(11, base * 0.028));
            p.text(label, cx, cy);
            p.fill(90);
            p.textSize(Math.max(11, base * 0.026));
            p.text('Scroll to explore the evidence', cx, cy + rOuter + base * 0.12);
            p.pop();
        }
    };
})();
