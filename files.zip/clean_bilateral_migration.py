"""
IMT 561 HWK 5 — Data Cleaning Script (Bilateral Migration)
============================================================
Dataset: UN DESA International Migrant Stock 2024: Destination and Origin
Source:   https://www.un.org/development/desa/pd/content/international-migrant-stock
File:     undesa_pd_2024_ims_stock_by_sex_destination_and_origin.xlsx
Tab:      Table 1

This script extracts and cleans bilateral migration data showing
how many foreign-born people from each origin country are living
in South Africa, across census years 1990–2024.

Steps:
  1. Load Table 1 from the UN DESA Excel file, skip metadata rows
  2. Assign readable column names (both-sexes, male, female × 8 years)
  3. Filter rows where destination = "South Africa"
  4. Remove aggregate/regional rows (keep only country-level origins)
  5. Keep only both-sexes columns (drop male/female breakdowns)
  6. Melt wide year columns into long format
  7. Clean types and handle missing/placeholder values
  8. Add continent/region labels for each origin country
  9. Sort and save

Output: SA_migration_by_origin_cleaned.csv
"""

import pandas as pd

# ── Step 1: Load Table 1, skip 10 metadata rows ─────────────────────
df = pd.read_excel(
    "undesa_pd_2024_ims_stock_by_sex_destination_and_origin.xlsx",
    sheet_name="Table 1",
    header=None,
    skiprows=10
)
print(f"Step 1 — Raw shape: {df.shape}")

# ── Step 2: Assign column names ──────────────────────────────────────
df.columns = [
    "Index", "Destination", "Coverage", "Data_Type", "Dest_Code",
    "Origin", "Origin_Code",
    "Both_1990","Both_1995","Both_2000","Both_2005","Both_2010","Both_2015","Both_2020","Both_2024",
    "Male_1990","Male_1995","Male_2000","Male_2005","Male_2010","Male_2015","Male_2020","Male_2024",
    "Female_1990","Female_1995","Female_2000","Female_2005","Female_2010","Female_2015","Female_2020","Female_2024"
]
print(f"Step 2 — Assigned {len(df.columns)} column names")

# ── Step 3: Filter destination = South Africa ────────────────────────
za = df[df["Destination"].str.strip() == "South Africa"].copy()
print(f"Step 3 — South Africa rows: {len(za)}")

# ── Step 4: Remove aggregates, keep country-level origins ────────────
#   Country codes < 900 are actual countries in the UN system
#   Codes >= 900 are regions/aggregates (World=900, Africa=903, etc.)
za["Origin_Code_Num"] = pd.to_numeric(za["Origin_Code"], errors="coerce")
za_countries = za[za["Origin_Code_Num"] < 900].copy()
# Also remove "Other South", "Other North" residual rows
za_countries = za_countries[~za_countries["Origin"].str.strip().str.startswith("Other")]
print(f"Step 4 — Country-level origins: {len(za_countries)} (removed {len(za) - len(za_countries)} aggregates)")

# ── Step 5: Keep only both-sexes year columns ────────────────────────
keep_cols = ["Origin", "Origin_Code",
             "Both_1990","Both_1995","Both_2000","Both_2005",
             "Both_2010","Both_2015","Both_2020","Both_2024"]
za_slim = za_countries[keep_cols].copy()
za_slim.columns = ["Origin_Country", "Origin_Code",
                    "1990","1995","2000","2005","2010","2015","2020","2024"]
za_slim["Origin_Country"] = za_slim["Origin_Country"].str.strip()
# Remove asterisks from country names
za_slim["Origin_Country"] = za_slim["Origin_Country"].str.replace("*", "", regex=False).str.strip()
print(f"Step 5 — Kept both-sexes columns, {len(za_slim.columns)} cols total")

# ── Step 6: Melt to long format ──────────────────────────────────────
year_cols = ["1990","1995","2000","2005","2010","2015","2020","2024"]
df_long = za_slim.melt(
    id_vars=["Origin_Country", "Origin_Code"],
    value_vars=year_cols,
    var_name="Year",
    value_name="Migrant_Stock"
)
print(f"Step 6 — Long format: {df_long.shape}")

# ── Step 7: Clean types ──────────────────────────────────────────────
df_long["Year"] = df_long["Year"].astype(int)
df_long["Migrant_Stock"] = pd.to_numeric(df_long["Migrant_Stock"], errors="coerce").fillna(0).astype(int)
# Remove rows where stock is 0 across all years for that country
nonzero = df_long.groupby("Origin_Country")["Migrant_Stock"].sum()
active_countries = nonzero[nonzero > 0].index
df_long = df_long[df_long["Origin_Country"].isin(active_countries)]
print(f"Step 7 — After removing zero-stock countries: {df_long['Origin_Country'].nunique()} countries, {len(df_long)} rows")

# ── Step 8: Add continent labels ─────────────────────────────────────
continent_map = {
    "Zimbabwe":"Africa","Mozambique":"Africa","Lesotho":"Africa","Malawi":"Africa",
    "Ethiopia":"Africa","Democratic Republic of the Congo":"Africa","Somalia":"Africa",
    "Namibia":"Africa","Congo":"Africa","Nigeria":"Africa","Zambia":"Africa",
    "Burundi":"Africa","Ghana":"Africa","Eswatini":"Africa","Botswana":"Africa",
    "Uganda":"Africa","Angola":"Africa","United Republic of Tanzania":"Africa",
    "Kenya":"Africa","Cameroon":"Africa","Rwanda":"Africa","Eritrea":"Africa",
    "South Sudan":"Africa","Sudan":"Africa","Madagascar":"Africa","Senegal":"Africa",
    "Côte d'Ivoire":"Africa","Mali":"Africa","Sierra Leone":"Africa","Guinea":"Africa",
    "Liberia":"Africa","Niger":"Africa","Benin":"Africa","Burkina Faso":"Africa",
    "Togo":"Africa","Central African Republic":"Africa","Chad":"Africa",
    "Egypt":"Africa","Libya":"Africa","Tunisia":"Africa","Morocco":"Africa","Algeria":"Africa",
    "Mauritius":"Africa","Cabo Verde":"Africa","Comoros":"Africa","Djibouti":"Africa",
    "Equatorial Guinea":"Africa","Gabon":"Africa","Gambia":"Africa",
    "Guinea-Bissau":"Africa","Mauritania":"Africa","Sao Tome and Principe":"Africa",
    "Seychelles":"Africa",
    "United Kingdom":"Europe","Germany":"Europe","Portugal":"Europe","Italy":"Europe",
    "Netherlands":"Europe","France":"Europe","Greece":"Europe","Switzerland":"Europe",
    "Belgium":"Europe","Ireland":"Europe","Poland":"Europe","Spain":"Europe",
    "Austria":"Europe","Sweden":"Europe","Romania":"Europe","Türkiye":"Europe",
    "Russian Federation":"Europe","Ukraine":"Europe","Serbia":"Europe",
    "Hungary":"Europe","Czechia":"Europe","Croatia":"Europe","Lithuania":"Europe",
    "Bulgaria":"Europe",
    "India":"Asia","Bangladesh":"Asia","Pakistan":"Asia","China":"Asia",
    "Philippines":"Asia","Sri Lanka":"Asia","Republic of Korea":"Asia",
    "Thailand":"Asia","Japan":"Asia","Israel":"Asia","Iran (Islamic Republic of)":"Asia",
    "Iraq":"Asia","Myanmar":"Asia","Nepal":"Asia","Malaysia":"Asia",
    "Syrian Arab Republic":"Asia","State of Palestine":"Asia","Lebanon":"Asia",
    "Taiwan Province of China":"Asia","Jordan":"Asia",
    "United States of America":"North America","Canada":"North America",
    "Brazil":"South America","Argentina":"South America","Colombia":"South America",
    "Cuba":"Caribbean","Jamaica":"Caribbean","Haiti":"Caribbean",
    "Australia":"Oceania","New Zealand":"Oceania",
}
df_long["Continent"] = df_long["Origin_Country"].map(continent_map).fillna("Other")
print(f"Step 8 — Added continent labels")

# ── Step 9: Sort and save ────────────────────────────────────────────
df_long = df_long.sort_values(["Year", "Migrant_Stock"], ascending=[True, False])
df_long = df_long.reset_index(drop=True)
df_long.to_csv("SA_migration_by_origin_cleaned.csv", index=False)

print(f"\nStep 9 — Saved SA_migration_by_origin_cleaned.csv")
print(f"         Final shape: {df_long.shape}")
print(f"         Year range: {df_long['Year'].min()} – {df_long['Year'].max()}")
print(f"         Unique countries: {df_long['Origin_Country'].nunique()}")
print(f"\nTop 10 origin countries (2024 migrant stock in SA):")
latest = df_long[df_long["Year"]==2024].head(10)
print(latest[["Origin_Country","Continent","Migrant_Stock"]].to_string(index=False))

print(f"\nContinent breakdown (2024):")
cont = df_long[df_long["Year"]==2024].groupby("Continent")["Migrant_Stock"].sum().sort_values(ascending=False)
for c, v in cont.items():
    print(f"  {c}: {v:,}")
