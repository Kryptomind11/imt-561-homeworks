// viz_progress_color.js
// Router for time-series / distribution charts.
//   ai 7  -> HR beat-by-beat time series, two subjects x two conditions (full-viz)
//   ai 8  -> HRV (BPM std) dot strips with mean markers
//   ai 12 -> sleep quality box plots by sleep disorder
(function () {
    var U = function () { return window.ChartUtils; };
    function fmtGroup(g) {
        return ({ chi_meditation: 'Chi', kundalini_yoga: 'Kundalini' })[g] || g;
    }

    // ---- ai 7 : dual time series ----
    function timeseries(p, m, prog) {
        var C = U(), f = C.frame(m), ts = (m.medData && m.medData.hr_timeseries) || {};
        var keys = Object.keys(ts);
        if (!keys.length) return;
        C.title(p, f, 'Heart rate, beat by beat',
            'Chi (top) and Kundalini (bottom): pre-meditation vs. during');
        var rev = C.reveal(prog);
        var pairs = [
            { name: 'Chi (C1)', pre: 'C1_pre_meditation', med: 'C1_meditation' },
            { name: 'Kundalini (Y1)', pre: 'Y1_pre_meditation', med: 'Y1_meditation' }
        ];
        var gap = 18, paneH = (f.h - gap) / 2;
        for (var pi = 0; pi < pairs.length; pi++) {
            var pane = { x: f.x, y: f.y + pi * (paneH + gap), w: f.w, h: paneH, ox: f.ox, oy: f.oy, W: f.W, H: f.H };
            var pre = ts[pairs[pi].pre] || [], med = ts[pairs[pi].med] || [];
            var all = pre.concat(med).map(function (d) { return d.bpm; });
            if (!all.length) continue;
            var lo = Math.min.apply(null, all) - 4, hi = Math.max.apply(null, all) + 4;
            // pane grid
            p.stroke(C.PALETTE.grid[0], C.PALETTE.grid[1], C.PALETTE.grid[2]); p.strokeWeight(1);
            for (var g = 0; g <= 2; g++) p.line(pane.x, pane.y + pane.h * g / 2, pane.x + pane.w, pane.y + pane.h * g / 2);
            drawLine(p, pane, pre, lo, hi, C.PALETTE.slate, rev);
            drawLine(p, pane, med, lo, hi, C.PALETTE.blue, rev);
            p.noStroke(); p.fill(C.PALETTE.ink); p.textSize(12); p.textAlign(p.LEFT, p.TOP);
            p.text(pairs[pi].name, pane.x + 4, pane.y + 4);
            p.fill(150); p.textAlign(p.RIGHT, p.TOP); p.textSize(9);
            p.text(Math.round(hi) + ' bpm', pane.x + pane.w, pane.y + 2);
            p.textAlign(p.RIGHT, p.BOTTOM); p.text(Math.round(lo) + ' bpm', pane.x + pane.w, pane.y + pane.h);
        }
        p.noStroke(); p.textSize(11); p.textAlign(p.CENTER, p.TOP); p.fill(120);
        p.text('normalized session time  →', f.x + f.w / 2, f.y + f.h + 22);
        legend(p, f, [['Pre-meditation', C.PALETTE.slate], ['During', C.PALETTE.blue]]);
    }
    function drawLine(p, pane, data, lo, hi, col, rev) {
        if (!data.length) return;
        var n = Math.floor(data.length * rev);
        p.noFill(); p.stroke(col[0], col[1], col[2], 220); p.strokeWeight(1.6);
        p.beginShape();
        for (var i = 0; i < n; i++) {
            var d = data[i];
            var x = pane.x + d.t * pane.w;
            var y = pane.y + pane.h - (d.bpm - lo) / (hi - lo) * pane.h;
            p.vertex(x, y);
        }
        p.endShape(); p.noStroke();
    }

    // ---- ai 8 : HRV dot strips ----
    function hrv(p, m, prog) {
        var C = U(), f = C.frame(m), d = (m.medData && m.medData.hrv) || [];
        if (!d.length) return;
        C.title(p, f, 'Heart-rate variability (BPM std. dev.)',
            'Higher spread during meditation in Kundalini; lower in Chi');
        var rev = C.reveal(prog);
        // order rows: chi pre, chi med, kun pre, kun med
        var order = [
            ['chi_meditation', 'pre_meditation'], ['chi_meditation', 'meditation'],
            ['kundalini_yoga', 'pre_meditation'], ['kundalini_yoga', 'meditation']
        ];
        var rows = order.map(function (o) {
            return d.find(function (r) { return r.group === o[0] && r.condition === o[1]; });
        }).filter(Boolean);
        var allVals = [];
        rows.forEach(function (r) { allVals = allVals.concat(r.values); });
        var lo = 0, hi = Math.max.apply(null, allVals) + 3;
        var rowH = f.h / rows.length;
        if (!m._hrvJit) m._hrvJit = {};
        for (var i = 0; i < rows.length; i++) {
            var r = rows[i], cy = f.y + i * rowH + rowH / 2;
            var col = r.condition === 'meditation' ? C.PALETTE.blue : C.PALETTE.slate;
            // baseline
            p.stroke(C.PALETTE.grid[0], C.PALETTE.grid[1], C.PALETTE.grid[2]); p.strokeWeight(1);
            p.line(f.x + 110, cy, f.x + f.w, cy); p.noStroke();
            var kk = r.group + r.condition;
            if (!m._hrvJit[kk]) m._hrvJit[kk] = r.values.map(function () { return (Math.random() - 0.5) * rowH * 0.4; });
            for (var v = 0; v < r.values.length; v++) {
                var x = f.x + 110 + (r.values[v] - lo) / (hi - lo) * (f.w - 110) * rev;
                p.fill(col[0], col[1], col[2], 150);
                p.ellipse(x, cy + m._hrvJit[kk][v], 9, 9);
            }
            // mean marker
            var mx = f.x + 110 + (r.mean - lo) / (hi - lo) * (f.w - 110) * rev;
            p.stroke(C.PALETTE.ink[0], C.PALETTE.ink[1], C.PALETTE.ink[2]); p.strokeWeight(2.4);
            p.line(mx, cy - rowH * 0.28, mx, cy + rowH * 0.28); p.noStroke();
            p.fill(C.PALETTE.ink); p.textAlign(p.CENTER, p.BOTTOM); p.textSize(11);
            p.text(r.mean.toFixed(1), mx, cy - rowH * 0.30);
            p.fill(90); p.textAlign(p.RIGHT, p.CENTER); p.textSize(11);
            p.text(fmtGroup(r.group) + ' · ' + (r.condition === 'meditation' ? 'during' : 'pre'), f.x + 104, cy);
        }
        p.noStroke(); p.fill(120); p.textAlign(p.CENTER, p.TOP); p.textSize(11);
        p.text('BPM standard deviation  →', f.x + (f.w + 110) / 2, f.y + f.h + 22);
    }

    // ---- ai 12 : box plots by disorder ----
    function boxPlot(p, m, prog) {
        var C = U(), f = C.frame(m), d = (m.medData && m.medData.sleep_disorder_box) || [];
        if (!d.length) return;
        C.title(p, f, 'Sleep quality by sleep disorder',
            'Box = IQR · line = median · whiskers = min/max');
        var rev = C.reveal(prog);
        var lo = 3.5, hi = 9.5;
        function sy(v) { return f.y + f.h - (v - lo) / (hi - lo) * f.h; }
        // y grid
        p.stroke(C.PALETTE.grid[0], C.PALETTE.grid[1], C.PALETTE.grid[2]); p.strokeWeight(1);
        for (var g = 4; g <= 9; g++) {
            p.line(f.x, sy(g), f.x + f.w, sy(g));
            p.noStroke(); p.fill(150); p.textAlign(p.RIGHT, p.CENTER); p.textSize(10);
            p.text(g, f.x - 6, sy(g)); p.stroke(C.PALETTE.grid[0], C.PALETTE.grid[1], C.PALETTE.grid[2]);
        }
        p.noStroke();
        var colByDis = { None: C.PALETTE.green, Insomnia: C.PALETTE.red, 'Sleep Apnea': C.PALETTE.amber };
        var slot = f.w / d.length, bw = Math.min(80, slot * 0.4);
        for (var i = 0; i < d.length; i++) {
            var b = d[i], cx = f.x + slot * (i + 0.5);
            var col = colByDis[b.disorder] || C.PALETTE.slate;
            var a = rev;
            // whiskers
            p.stroke(col[0], col[1], col[2]); p.strokeWeight(1.5);
            p.line(cx, sy(b.min), cx, sy(b.max));
            p.line(cx - bw * 0.2, sy(b.min), cx + bw * 0.2, sy(b.min));
            p.line(cx - bw * 0.2, sy(b.max), cx + bw * 0.2, sy(b.max));
            // box
            p.noStroke(); p.fill(col[0], col[1], col[2], 70 + 80 * a);
            var y3 = sy(b.q3), y1 = sy(b.q1);
            p.rect(cx - bw / 2, y3, bw, y1 - y3, 3);
            p.stroke(col[0], col[1], col[2]); p.strokeWeight(1.5); p.noFill();
            p.rect(cx - bw / 2, y3, bw, y1 - y3, 3);
            // median
            p.strokeWeight(2.6); p.line(cx - bw / 2, sy(b.median), cx + bw / 2, sy(b.median));
            p.noStroke();
            // labels
            p.fill(C.PALETTE.ink); p.textAlign(p.CENTER, p.TOP); p.textSize(12);
            p.text(b.disorder, cx, f.y + f.h + 6);
            p.fill(150); p.textSize(10);
            p.text('n=' + b.n, cx, f.y + f.h + 22);
            p.fill(col[0], col[1], col[2]); p.textAlign(p.LEFT, p.CENTER); p.textSize(11);
            p.text('med ' + b.median, cx + bw / 2 + 6, sy(b.median));
        }
    }
    function legend(p, f, items) {
        var x = f.x, y = f.oy + f.H - 16;
        p.textSize(11); p.textAlign(p.LEFT, p.CENTER);
        for (var i = 0; i < items.length; i++) {
            var c = items[i][1];
            p.noStroke(); p.fill(c[0], c[1], c[2]); p.rect(x, y - 5, 11, 11, 2);
            p.fill(90); p.text(items[i][0], x + 16, y);
            x += 16 + p.textWidth(items[i][0]) + 20;
        }
    }

    window.VizProgressColor = {
        draw: function (p, manager, ai, progress) {
            if (!manager.medData) return;
            p.push();
            if (ai === 7) timeseries(p, manager, progress);
            else if (ai === 8) hrv(p, manager, progress);
            else if (ai === 12) boxPlot(p, manager, progress);
            p.pop();
        }
    };
})();
